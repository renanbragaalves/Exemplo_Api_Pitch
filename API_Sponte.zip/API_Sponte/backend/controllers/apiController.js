const { login} = require('../utils/apiHelper');

async function readRecord(req, res) {
    try {
        const token = await login();
        console.log('Receive Token:', token);  // Log the received token
    } catch (error) {
        console.log('Error in readRecord:', error);  // Log any errors
        res.status(500).send(error.message);
    }
}

module.exports = { readRecord };
