const axios = require('axios');
require('dotenv').config();

const { API_USERNAME, API_PASSWORD } = process.env;

const API_BASE_URL = 'https://integracao.sponteweb.net.br/api/v2';

async function login() {
  try {
    console.log(API_USERNAME, API_PASSWORD)
    console.log('Axios Config:', axios.defaults); // Log the Axios configuration
    const response = await axios.post(`${API_BASE_URL}/login`, {
      login: API_USERNAME,
      senha: API_PASSWORD
    });
    console.log('Login Response:', response.data); // Log the login response
    return {
        token: response.data.token,
        statusCode: response.status
    };
  } catch (error) {
    console.error('Error during login:', error);
    throw new Error('Login Failed');
  }
}

// async function getRecord(token, endpoint) {
//   try {
//     const axiosConfig = {
//       headers: {
//         'Accept': 'text/plain',
//         'Authorization': `Bearer ${token}`
//       },
//       params: {
//         'Situacao': -1,
//         'Pagina': 1
//       }
//     };

//     const response = await axios.get(`${API_BASE_URL}/${endpoint}`, axiosConfig);
//     console.log('Axios GET Response:', response.data); // Log the received data from Axios
//     return response.data;
//   } catch (error) {
//     console.error('Axios GET Error:', error.response || error); // Log the error from Axios
//     throw new Error('Could not retrieve record.');
//   }
// }

module.exports = { login};
